# egrn_parser v1.10

Система парсинга и мониторинга выписок ЕГРН.

**Python 3.13+ · Windows 10 · SQLite · XLSX · JSON · graph.json v1.1**

---

## Возможности

| Источник | Результат |
|----------|-----------|
| PDF-выписки ЕГРН (полные / краткие) | land_objects, building_objects, rights, valuations |
| XML-выписки ЕГРН | То же + object_restrictions |
| ОСВ 1С (счёт 01.01 / 01.К) | accessories, valuations |
| DOCX-перечни имущества | Дополнительные объекты |
| Шаблон Assets XLSX | Обогащение полей |

**Экспорт:** SQLite · XLSX (14 листов) · JSON · graph.json v1.1 (Block 2)

---

## Установка

```bash
pip install -e .
# Для API:
pip install -e ".[api]"
```

---

## Быстрый старт

```bash
# Интерактивный режим
python -m egrn_parser

# Парсинг папки с выписками
egrn-parser parse --input ./input --db ./output/egrn.db

# Экспорт
egrn-parser export --db ./output/egrn.db --output ./output

# Миграция v1.9 → v1.10
egrn-parser migrate --db ./egrn.db

# Загрузка словарей
egrn-parser dict-load --db ./egrn.db

# Управление папками
egrn-parser folders create --root ./ОБЪЕКТЫ --cad-file кадастры.txt
egrn-parser folders distribute --root ./ОБЪЕКТЫ --source ./Входящие
egrn-parser folders validate --root ./ОБЪЕКТЫ
```

---

## Архитектура

```
egrn_parser/
├── parsers/       — PDF, XML, ОСВ, DOCX, шаблон
├── enrichers/     — обогащение, resolve_room_parent
├── merge/         — diff, interactive, upsert
├── exporters/     — XLSX (14 листов), JSON, graph.json
├── monitoring/    — мониторинг объектов
├── db/            — schema.sql, connection, migrations, seeds
└── utils/         — кодировки, фильтры, персональные данные
```

---

## Ключевые правила (ТЗ v1.10)

- **Персональные данные** (`Сведения о возможности предоставления третьим лицам...`) — никогда не сохраняются ни в одном выходном формате.
- **right_category** всегда `'right'` | `'encumbrance'` | `'restriction'` — без устаревшей склейки через ` | `.
- **object_restrictions** — JSON-массив в land_objects/building_objects, **не** в rights.
- **Листы 1–2 XLSX** (A–U / A–AC) — структура не изменяется, новые поля добавляются справа.
- **Идемпотентность** — через `(extract_number, content_hash)`.

---

## Выходные листы XLSX

| № | Лист | Источник |
|---|------|----------|
| 1 | Земельные участки | land_objects + расширенные V–AH |
| 2 | Здания, сооружения | building_objects + AD–AU |
| 3 | Помещения и машино-места | building_objects (room/parking) |
| 4 | ОНС | building_objects (ons) |
| 5 | Принадлежности и оборудование | accessories |
| 6 | Бизнес-единицы | business_units |
| 7 | Права | rights (right_category='right') |
| 8 | Обременения | rights (right_category='encumbrance') |
| 9 | Ограничения | rights (restriction) + object_restrictions JSON |
| 10 | Правообладатели | right_holders + entity_registry |
| 11 | События объектов | object_events |
| 12 | События прав | right_events |
| 13 | Оценка стоимости | valuations |
| 14 | Словарь кодов | code_dictionary |

---

## Зависимости

```
pdfplumber>=0.11   — парсинг PDF
openpyxl>=3.1     — XLSX чтение/запись
python-docx>=1.1  — DOCX-перечни
fastapi + uvicorn — API (опционально)
shapely + pyproj  — геометрия (опционально)
```
